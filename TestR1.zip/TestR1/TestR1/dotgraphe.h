#ifndef TESTR1_DOTGRAPHE_H
#define TESTR1_DOTGRAPHE_H

void generate_dot_file(const char *input_file, const char *output_file);

#endif // TESTR1_DOTGRAPHE_H
